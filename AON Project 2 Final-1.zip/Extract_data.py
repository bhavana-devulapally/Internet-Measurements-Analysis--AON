
import os
import csv
import re

from collections import defaultdict

def extract_info(file_path):
    with open(file_path, 'r') as file:
        # Extract information from the file name using regular expressions
        match = re.match(r'(\d+)www\.(.*?)-(\d+\w{3})\.txt', os.path.basename(file_path))
        if match:
            run_number, domain_name, date = match.groups()
        else:
            return None

        # Extract information from each line (1-30) in the text file
        lines = file.read().split('\n')[1:31]
        info_list = []
        for line_num, line in enumerate(lines, 1):
            elements = line.split()
            if len(elements) == 5 and any(e != '*' for e in elements[1:]):  # Ignore lines with '* * *'
                ip, rtt1, rtt2, rtt3 = elements[1:]
                hop_number = line_num  # Hop number is the line number
                info_list.append({
                    'IP': ip,
                    'RTT1': rtt1,
                    'RTT2': rtt2,
                    'RTT3': rtt3,
                    'Domain Name': f'www.{domain_name}',
                    'Date': date,
                    'Hop Number': hop_number,
                    'Run Number': run_number
                })

        return info_list

def write_to_csv(data, output_file='traceroute_data.csv'):
    fieldnames = ['IP', 'RTT1', 'RTT2', 'RTT3', 'Domain Name', 'Date', 'Hop Number', 'Run Number', 'AS Number']
    file_exists = os.path.exists(output_file)

    with open(output_file, 'a', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

        # Write the header only if the file is empty
        if not file_exists or csvfile.tell() == 0:
            writer.writeheader()

        writer.writerows(data)

def get_as_number(ip):
    try:
        # Send HTTP GET request to Cymru API
        response = requests.get(f'https://api.cymru.com/v2/ip/{ip}')
        if response.status_code == 200:
            # Parse AS number from the JSON response
            as_number = response.json().get('asn')
            return str(as_number)
    except Exception as e:
        print(f"Error getting AS number for IP {ip}: {e}")
    return None

if __name__ == '__main__':
    input_folder = '28th November 2023'  # Specify the folder containing your text files
    output_csv_file = 'traceroute_data_alldays_AS_Hop123.csv'

    domain_data_dict = defaultdict(list)

    # Iterate through all text files in the folder
    for filename in os.listdir(input_folder):
        if filename.endswith('.txt'):
            file_path = os.path.join(input_folder, filename)
            extracted_data = extract_info(file_path)

            if extracted_data:
                domain_name = extracted_data[0]['Domain Name']

                # Get AS number for each IP in the extracted data
                for row in extracted_data:
                    ip = row['IP']
                    as_number = get_as_number(ip)
                    row['AS Number'] = as_number

                domain_data_dict[domain_name].extend(extracted_data)

    # Sort data by date, domain name, and hop number
    sorted_data = []
    for domain_name, domain_data in sorted(domain_data_dict.items()):
        sorted_data.extend(sorted(domain_data, key=lambda x: (x['Date'], x['Domain Name'], x['Hop Number'])))

    # Write the sorted data to the CSV file
    write_to_csv(sorted_data, output_csv_file)

    print(f"CSV file updated successfully: {output_csv_file}")
