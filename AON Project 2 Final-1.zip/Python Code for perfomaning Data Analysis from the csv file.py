# -*- coding: utf-8 -*-
"""
Created on Wed Dec  6 17:40:47 2023

@author: bhava
"""

import pandas as pd
from matplotlib import pyplot as plt
from matplotlib_venn import venn2

def router_latency_analysis(rtt_values):
    print("Router Latency Assessment:")
    for index, rtt in enumerate(rtt_values):
        print(f"Router {index + 1}: RTT values - {rtt}")

def path_latency_estimation(rtt_values):
    print("\nPath Latency Estimation:")
    for hop, rtt in enumerate(zip(*rtt_values)):
        available_rtt = [val for val in rtt if isinstance(val, (int, float))]
        if available_rtt:
            avg_rtt = sum(available_rtt) / len(available_rtt)
            print(f"Hop {hop + 1}: Average RTT - {avg_rtt:.3f}")
        else:
            print(f"Hop {hop + 1}: All RTT values unavailable")

def network_performance_assessment(rtt_values):
    print("\nNetwork Performance Assessment:")
    for run, rtt in enumerate(rtt_values):
        available_rtt = [val if val != '*' else None for val in rtt]
        filtered_rtt = [val for val in available_rtt if val is not None]
        if filtered_rtt:
            max_rtt = max(filtered_rtt)
            print(f"Hop {run + 1}: Max RTT value - {max_rtt}")
        else:
            print(f"Hop {run + 1}: All RTT values unavailable")

def identify_bottlenecks(rtt_values):
    print("\nIdentifying Bottlenecks:")
    for run, rtt in enumerate(rtt_values):
        available_rtt = [val if val != '*' else None for val in rtt]
        filtered_rtt = [val for val in available_rtt if val is not None]
        if filtered_rtt:
            mean_rtt = sum(filtered_rtt) / len(filtered_rtt)
            print(f"Hop {run + 1}: Mean RTT value - {mean_rtt:.3f}")
        else:
            print(f"Hop {run + 1}: All RTT values unavailable")
            
            
url = "https://raw.githubusercontent.com/bhavana-devulapally/Amazon-Project/main/traceroute_data_alldays_AS_Hop_updated_sorted.csv"

df = pd.read_csv(url)
df= df.query("`Domain Name` == 'www.payments.pitt.edu'")
df=df.query("`Date` == '28-Nov'")

df.head(20)
grouped_data = df.groupby('Run Number')



ip_sets = [list(group['IP']) for _, group in grouped_data]
for i in range(len(ip_sets)-1):
  for j in range(i+1,len(ip_sets)):
    if ip_sets[i]==ip_sets[j]:
      print(f"Run {i} and Run {j} are the same : {ip_sets[j]}")
    else:
        print("No paths are same")
    
print("\n")
print("The pitt payments IP routes on November 28 are outlined as follows:")
for i in ip_sets:
  print(i)
  
  
  
for k in range(1,7):
  rtt_values=[]
  for i, row in df.iterrows():
        if row["Run Number"] == k:
            l1 = []
            if row["RTT1"] == '*':
                l1.append('*')
            else:
                RTT1 = float(row["RTT1"][:-2])
                l1.append(RTT1)

            if row["RTT2"] == '*':
                l1.append('*')
            else:
                RTT2 = float(row["RTT2"][:-2])
                l1.append(RTT2)

            if row["RTT3"] == '*':
                l1.append('*')
            else:
                RTT3 = float(row["RTT3"][:-2])
                l1.append(RTT3)
          

            rtt_values.append(l1)
  print()
  print(f"RTT Values for Run {k} is {rtt_values}")
  print()
  router_latency_analysis(rtt_values)
  path_latency_estimation(rtt_values)
  network_performance_assessment(rtt_values)
  identify_bottlenecks(rtt_values)

