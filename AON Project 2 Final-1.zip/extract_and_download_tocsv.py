# -*- coding: utf-8 -*-
"""
Created on Wed Nov 29 15:30:40 2023

@author: bhava
"""
"""
import csv

def process_traceroute_data(data):
    lines = data.split('\n')[1:31]  # Extract lines 1 to 30
    rows = []
    l2=[]
    for line in lines:
        
        elements = line.split()
        l2.append(elements)
    
        if len(elements) == 5 and any(e != '*' for e in elements[1:]):  # Ignore lines with '* * *'
            ip = elements[1]
            rtt1, rtt2, rtt3 = elements[2:]
            rows.append({'IP': ip, 'RTT1': rtt1, 'RTT2': rtt2, 'RTT3': rtt3})
    
    print(rows)
    return rows

def write_to_csv(rows, output_file='traceroute_data.csv'):
    fieldnames = ['IP', 'RTT1', 'RTT2', 'RTT3']

    with open(output_file, 'w', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

if __name__ == '__main__':
    # Replace 'your_input_file.txt' with the actual name of your input file
    with open('1www.amazon.com-24Nov.txt', 'r') as file:
        data = file.read()

    extracted_data = process_traceroute_data(data)
    write_to_csv(extracted_data)

    print("CSV file created successfully: traceroute_data.csv")
"""

import os
import csv

def process_traceroute_data(data):
    lines = data.split('\n')[1:31]  # Extract lines 1 to 30
    rows = []
    for line in lines:
        elements = line.split()
        if len(elements) == 5 and any(e != '*' for e in elements[1:]):  # Ignore lines with '* * *'
            ip, rtt1, rtt2, rtt3 = elements[1:]
            rows.append({'IP': ip, 'RTT1': rtt1, 'RTT2': rtt2, 'RTT3': rtt3})
    return rows

def write_to_csv(rows, output_file='traceroute_data.csv'):
    fieldnames = ['IP', 'RTT1', 'RTT2', 'RTT3']
    with open(output_file, 'a', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writerows(rows)

if __name__ == '__main__':
    input_folder = '28th November 2023'  # Specify the folder containing your text files
    output_csv_file = 'traceroute_data29th_Nov.csv'

    # Iterate through all text files in the folder
    for filename in os.listdir(input_folder):
        if filename.endswith('.txt'):
            file_path = os.path.join(input_folder, filename)
            with open(file_path, 'r') as file:
                data = file.read()
            
            extracted_data = process_traceroute_data(data)
            write_to_csv(extracted_data, output_csv_file)

    print(f"CSV file created successfully: {output_csv_file}")
