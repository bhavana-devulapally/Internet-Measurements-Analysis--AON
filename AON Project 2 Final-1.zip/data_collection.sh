#!/bin/bash
destinations=("www.linkedin.com")
measurements_per_destination=6

for destination in "${destinations[@]}"; do 
    # Loop to collect measurements
    for ((measurement=1; measurement<=$measurements_per_destination; measurement++)); do
        filename="${measurement}${destination}-28Nov.txt"
        traceroute -m 30 "$destination" > "$filename"
        sleep 3 # Sleep for 1 hour (adjust as needed)
    done
done

